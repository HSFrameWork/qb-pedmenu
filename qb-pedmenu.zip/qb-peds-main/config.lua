Config = {}


Config.discord = {
    ['webhook'] = 'yourwebhook',
    ['name'] = 'PedMenu',
    ['image'] = 'https://cdn.discordapp.com/avatars/869260464775921675/dea34d25f883049a798a241c8d94020c.png?size=1024'
}

